﻿<?php 
/*
Template Name:魅影
Description:Designed For Emlog
Version:1.0
Author:麦特佐罗
Author Url:http://hc123.site/zorro
Sidebar Amount:1
ForEmlog:5.3.0
*/
?>
<a href="javascript:grin('[F1]')" title="微笑"><img src="<?php echo TEMPLATE_URL; ?>images/face/1.gif" alt="微笑"/></a>
<a href="javascript:grin('[F2]')" title="大笑"><img src="<?php echo TEMPLATE_URL; ?>images/face/2.gif" alt="大笑"/></a>
<a href="javascript:grin('[F3]')" title="拽"><img src="<?php echo TEMPLATE_URL; ?>images/face/3.gif" alt="拽"/></a>
<a href="javascript:grin('[F4]')" title="大哭"><img src="<?php echo TEMPLATE_URL; ?>images/face/4.gif" alt="大哭"/></a>
<a href="javascript:grin('[F5]')" title="奸笑"><img src="<?php echo TEMPLATE_URL; ?>images/face/5.gif" alt="奸笑"/></a>
<a href="javascript:grin('[F6]')" title="流汗"><img src="<?php echo TEMPLATE_URL; ?>images/face/6.gif" alt="流汗"/></a>
<a href="javascript:grin('[F7]')" title="喷血"><img src="<?php echo TEMPLATE_URL; ?>images/face/7.gif" alt="喷血"/></a>
<a href="javascript:grin('[F8]')" title="生气"><img src="<?php echo TEMPLATE_URL; ?>images/face/8.gif" alt="生气"/></a>
<a href="javascript:grin('[F9]')" title="囧"><img src="<?php echo TEMPLATE_URL; ?>images/face/9.gif" alt="囧"/></a>
<a href="javascript:grin('[F10]')" title="不爽"><img src="<?php echo TEMPLATE_URL; ?>images/face/10.gif" alt="不爽"/></a>
<a href="javascript:grin('[F11]')" title="晕"><img src="<?php echo TEMPLATE_URL; ?>images/face/11.gif" alt="晕"/></a>
<a href="javascript:grin('[F12]')" title="示爱"><img src="<?php echo TEMPLATE_URL; ?>images/face/12.gif" alt="示爱"/></a>
<a href="javascript:grin('[F13]')" title="卖萌"><img src="<?php echo TEMPLATE_URL; ?>images/face/13.gif" alt="卖萌"/></a>
<a href="javascript:grin('[F14]')" title="吃惊"><img src="<?php echo TEMPLATE_URL; ?>images/face/14.gif" alt="吃惊"/></a>
<a href="javascript:grin('[F15]')" title="迷离"><img src="<?php echo TEMPLATE_URL; ?>images/face/15.gif" alt="迷离"/></a>
<a href="javascript:grin('[F16]')" title="爱你"><img src="<?php echo TEMPLATE_URL; ?>images/face/16.gif" alt="爱你"/></a>
<a href="javascript:grin('[F17]')" title="吓死了"><img src="<?php echo TEMPLATE_URL; ?>images/face/17.gif" alt="吓死了"/></a>
<a href="javascript:grin('[F18]')" title="呵呵"><img src="<?php echo TEMPLATE_URL; ?>images/face/18.gif" alt="呵呵"/></a>