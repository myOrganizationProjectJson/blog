﻿<?php
/*
Template Name:魅影
Description:Designed For Emlog
Version:1.0
Author:麦特佐罗
Author Url:http://hc123.site/zorro
Sidebar Amount:1
ForEmlog:5.3.0
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="content" role="main">
	<div class="page">
		<article role="article">
		抱歉，此模板不提供微语功能，呵呵 :)
		</article>
	</div>
</div>
<?php include View::getView('side'); ?>
<?php include View::getView('footer'); ?>